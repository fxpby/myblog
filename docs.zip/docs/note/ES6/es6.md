# ES6

## 1.let命令

### 基本用法

let命令用来声明变量，用法与var类似，但是所声明的变量只在其命令所在的代码块内有效。

```javascript
//举个例子
{
    let a = 1;
    var b = 2;
}
con

```
