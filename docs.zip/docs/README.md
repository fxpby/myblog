---
home: true
lang: zh-CN
heroText: Fxpby's blog
heroImage: /headImg.jpg
tagline: Welcome to my blog
actionText: 开始 →
actionLink: /note/
features:
- title: A Blog - 博客
  details: 记录自己日常所得，整理归纳。
- title: For Me - 关于我
  details: 天津理工大学 本科 2020届 软件工程专业 1037345919@qq.com。
footer: Copyright © 2020-present Fxpby
---